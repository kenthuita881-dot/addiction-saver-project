# Addiction Saver

Recovery-support website: addiction info, counselling guide, 10-book library, 5 handbooks, group meetings with RSVP, a day tracker gated by daily reading, counselors, one-on-one chat (KES 130 access) and an admin dashboard.

**Front end:** one file, `index.html`, with the CSS and JavaScript built in. Every menu item (Home, Addictions, Counselling guide, Book library, Handbooks, Meetings, My Tracker, Counselors, Private chat, Pricing, About Us, Contact Us) opens as its own page inside it. **Back end:** Python Flask + SQLite (`app.py`).

## Run locally
```
pip install -r requirements.txt
ADMIN_TOKEN=choose-a-secret python app.py      # Windows PowerShell: $env:ADMIN_TOKEN="choose-a-secret"; python app.py
```
Open http://localhost:5000 . Dashboard: http://localhost:5000/admin.html

## Tracking your clients
Open `/admin.html` and enter your `ADMIN_TOKEN`. You see clients (anonymous id, paid or not, method, phone, addiction, goal, readings done, messages, meeting RSVPs, last active), revenue, and call-back requests, with CSV download. Chat contents and journals are not shown to the admin, by design.

## Deploy (needs a server, GitHub Pages cannot run Flask)
Render.com: New > Blueprint > pick this repo (uses `render.yaml`; the disk keeps the database). Copy the generated `ADMIN_TOKEN` from the service's Environment tab.
Any host that runs `gunicorn app:app` works (Railway, Fly.io, PythonAnywhere).

## Payments
`DEMO_PAYMENTS = True` in `app.py` marks visitors paid without charging. Before launch, connect a real gateway in `/api/pay` (M-Pesa Daraja, card hosted fields, PayPal, Google Pay) and set the flag to False. Never send raw card numbers to your server.

## Editing meetings and handbooks
Open `index.html` and search for `const MEETINGS` (days, times in EAT, hosts and join links) and `const HANDBOOKS` (the guide text). If you add a meeting, also add its id to `MEETING_IDS` in `app.py`.
